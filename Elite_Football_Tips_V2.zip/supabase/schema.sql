-- Run in Supabase SQL Editor.
create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.predictions (
  id uuid primary key default gen_random_uuid(),
  fixture_id text not null,
  fixture_home text not null,
  fixture_away text not null,
  pick text not null,
  score_idea text,
  analysis text not null,
  published boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
alter table public.predictions enable row level security;
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.admin_users where user_id=auth.uid()); $$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;
create policy "Public can read published predictions" on public.predictions
for select to anon, authenticated using (published = true or public.is_admin());
create policy "Admins can insert predictions" on public.predictions
for insert to authenticated with check (public.is_admin());
create policy "Admins can update predictions" on public.predictions
for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admins can delete predictions" on public.predictions
for delete to authenticated using (public.is_admin());
-- Do not allow public reads of admin_users. is_admin() is the only intended check.
