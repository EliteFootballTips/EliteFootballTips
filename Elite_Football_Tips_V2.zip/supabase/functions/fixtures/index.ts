import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
const headers = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type" };
serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  try {
    const token = Deno.env.get("FOOTBALL_DATA_TOKEN");
    if (!token) throw new Error("Missing FOOTBALL_DATA_TOKEN secret");
    const url = new URL(req.url);
    const comp = url.searchParams.get("competition");
    const allowed = ["PL","PD","BL1","SA","FL1"];
    const endpoint = comp && allowed.includes(comp)
      ? `https://api.football-data.org/v4/competitions/${comp}/matches`
      : "https://api.football-data.org/v4/matches";
    const upstream = await fetch(endpoint, { headers: { "X-Auth-Token": token } });
    if (!upstream.ok) throw new Error(`Football data provider returned ${upstream.status}`);
    const raw = await upstream.json();
    const matches = (raw.matches || []).map((m: any) => ({
      id: m.id, competition: m.competition?.name || "Football",
      utcDate: m.utcDate, status: m.status, matchday: m.matchday,
      home: m.homeTeam?.name || "Home", away: m.awayTeam?.name || "Away",
      homeScore: m.score?.fullTime?.home ?? null,
      awayScore: m.score?.fullTime?.away ?? null
    }));
    return new Response(JSON.stringify({ matches, fetchedAt: new Date().toISOString() }), {
      headers: { ...headers, "Content-Type": "application/json", "Cache-Control": "public, max-age=60" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: { ...headers, "Content-Type": "application/json" } });
  }
});
